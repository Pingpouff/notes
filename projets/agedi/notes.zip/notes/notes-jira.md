# Filtre jira: [jira](https://extranet.artal.fr/jira-ng/issues/?jql=project%20%3D%20Agedi%20and%20component%20in%20(Bill%2C%20Meter%2C%20Bill-Common)%20and%20fixVersion%20in%20("Bill-Common%20V1"%2C%20"Bill%20V1")%20and%20status%20!%3D%20Closed%20and%20type%20%3D%20UserStory%20ORDER%20BY%20key)

### FI: Ajustement de la facture individuelle [jira](https://extranet.artal.fr/jira-ng/browse/AGD-1521)
