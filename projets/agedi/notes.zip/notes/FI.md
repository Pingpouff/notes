# Facture Individuelle
## [AGD-1515](https://extranet.artal.fr/jira-ng/browse/AGD-1515) Afficher la facture individuelle <a href="https://www.figma.com/file/L4SFjFKb7NOE4jqlZWGMGttH/Maquettes?node-id=6620%3A6541"><img  src="figma.png" alt="drawing" style="width: 20px;"/></a>
Création de la FI (7d)
- Afficher info usager
- pouvoir accéder à l'usager
- Pouvoir définir les informations sur la facture
- Tenir compte des informations défini dans le paramétrage
- Gérer les numéros de facture sur l'année
- Pouvoir définir les options d'export de la facture (mention / expéditeur)
- Afficher les informations de facturation de l'usager dans la grille
- Pouvoir modifier les informations de facturation
- Pouvoir modifier ou redéfinir le message perso
- Pouvoir transférer en régie la facture
- Pouvoir transférer en comptabilité la facture
- Respect des template d'export
- Possibilité de faire un aperçu SPECIMEN de la facture sans aucun impact d'archivage
- Possibilité d'intégrer les reports

## [AGD-1668](https://extranet.artal.fr/jira-ng/browse/AGD-1668) Liste des factures individuelles <a href="https://www.figma.com/file/L4SFjFKb7NOE4jqlZWGMGttH/Maquettes?node-id=7471%3A7019"><img  src="figma.png" alt="drawing" style="width: 20px;"/></a>
Datagrid des FI (6d).

Sur meter qu'on soit en mode par compteur ou par abonnée on ne fait qu'une FI pour un compteur
si on mode compteur on affiche une FI par compteur si abonnée on fait la même chose mais avec un regroupement par compteur ou alors on ne change rien ?

## [AGD-1701](https://extranet.artal.fr/jira-ng/browse/AGD-1701) Contrat en facture individuelle
Lister les abonné qui ne seront pas pris en compte sur le calcul des prochains rôles
- usagers exclus en facturation classique + prélevé + mensualisé ?
- On ne peut pas utiliser la modale du rôle qui fait déjà ça?
- écran à faire ?

TODO: ajouter la date de dernière FI, télécharger pdf FI et afficher intitulé FI
    le faire pour la modale du rôle et cet écran à plat

## [AGD-1713](https://extranet.artal.fr/jira-ng/browse/AGD-1713) Rapport détaillé sur les factures individuelles
- Que fait exactement cet export ? A quoi il sert ? Peut on le remplacer par l'export xlsx?
    REPONSE: c'est dans le cadre des stats
## [AGD-1713](https://extranet.artal.fr/jira-ng/browse/AGD-1518) Edition de la facture individuelle
template jasper des FI
