# Avancement

## 29/05/2018
- présentation des templates des factures
- présentation du rôle meter